package com.example.jeremie.intent;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        String recepIntent  = getIntent().getStringExtra("Message");
        TextView vierge = (TextView) findViewById(R.id.TexteVierge3_textView5);
        vierge.setText(recepIntent);
}

    @Override
    public void onBackPressed(){


        EditText Edit_C = (EditText) findViewById(R.id.EditC_editText);
        String TextC = Edit_C.getText().toString();
        Intent myIntent = new Intent(Activity3.this, MainActivity.class);
        myIntent.putExtra("backMessage", TextC);
        myIntent.putExtra("source","C");
        this.setResult(RESULT_OK, myIntent);

        super.onBackPressed();
    }

    @Override
    public void finish() {
        super.finish();

    }

}
